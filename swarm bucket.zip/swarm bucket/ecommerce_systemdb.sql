-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2023 at 11:42 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_systemdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `line1` varchar(255) DEFAULT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'Shoes'),
(2, 'Electronics');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `orders_details`
--

CREATE TABLE `orders_details` (
  `id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `images` text DEFAULT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `quantity` int(10) NOT NULL,
  `short_desc` varchar(255) NOT NULL,
  `cat_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `image`, `images`, `description`, `price`, `quantity`, `short_desc`, `cat_id`) VALUES
(1, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd;https://static.toiimg.com/thumb/msid-56933980,width-640,resizemode-4,imgsize-85436/56933980.jpg;https://cdn.mos.cms.futurecdn.net/3328be45e8c7fe5194055b4c687fb769-1200-80.jpeg;https://img.etimg.com/thumb/width-640,height-480,imgsize-76492,resizemode-1,msid-52464286/46.jpg', 'With PS4, gaming becomes a lot more power-packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play, and lots more make it the ultimate companion device.', 30000, 1000, 'Gaming console', 2),
(2, 'Airforce 1 07 Running Shoes For Men', 'https://images.stockx.com/360/Nike-Air-Force-1-Low-07-Fresh-White/Images/Nike-Air-Force-1-Low-07-Fresh-White/Lv2/img01.jpg?fm=avif&auto=compress&w=576&dpr=1&updated_at=1668756420&h=384&q=57', 'https://images.stockx.com/360/Nike-Air-Force-1-Low-07-Fresh-White/Images/Nike-Air-Force-1-Low-07-Fresh-White/Lv2/img01.jpg?fm=avif&auto=compress&w=576&dpr=1&updated_at=1668756420&h=384&q=57;https://images.stockx.com/360/Nike-Air-Force-1-Low-07-Fresh-White/Images/Nike-Air-Force-1-Low-07-Fresh-White/Lv2/img01.jpg?fm=avif&auto=compress&w=576&dpr=1&updated_at=1668756420&h=384&q=57', 'The Nike Airforce 1 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 9000, 1000, 'SPORTS SHOES', 1),
(3, 'MEN\'S ADIDAS RUNNING FORUMS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well-cushioned shoe with a fresher look that will appeal to young runners. Features a mesh upper for maximum ventilation, Lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces, and a durable rubber outsole for long-lasting wear', 10000, 100, 'SPORTS SHOES', 1),
(4, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for the console and Xbox Live Gold, and 1-month of EA Access.', 25000, 78, 'Gaming console', 2),
(5, 'Sony Alpha', 'https://m.media-amazon.com/images/I/71C5lgow9YL._SX679_.jpg', NULL, '61.0MP back-illuminated Exmor R CMOS sensor and a powerful BIONZ XR image processing engine, Accurate and broad subject recognition powered by the AI Processing Unit, Advanced image stabilization with up to an 8-step compensation effect, 8K 24/25p and 4K 50/60p movie recording, 4:2:2 10-bit, Real-time Eye AF for Human/Animal/Birds/Insects/Cars/Trains/Aeroplanes', 300000, 1000, 'Camera', 2),
(6, 'Dell Alienware', 'https://m.media-amazon.com/images/I/417JIz1AQiL._SX679_.jpg', NULL, 'Intel Core i9-13980HX Processor/64GB/1TB SSD/18.0" (45.72cm) QHD+ FHD 165Hz/NVIDIA RTX 4090 16GB GDDR6/Win 11 + MSO''21/15 Month McAfee/Dark Metallic Moon/2.72kg', 400000, 1, 'Laptop', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT 'not set',
  `age` int(10) DEFAULT 18,
  `role` int(10) DEFAULT 555,
  `photoUrl` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'local'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `full_name`, `age`, `role`, `photoUrl`, `type`) VALUES
(1, '', '2072cbc7f2ed127ef972a8b93f248e6c', 'ado@gmail.com', 'adones evangelista', 18, 555, NULL, 'local');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
